package kz.akarys.vrpass

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import android.view.Surface
import android.view.WindowManager
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs

/**
 * Камера суретін екі көзге бөліп, линзаға арналған barrel distortion қолданатын view.
 */
class VRView(context: Context) : GLSurfaceView(context) {

    private val renderer = StereoRenderer()

    private var cameraDevice: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var opening = false
    private var bgThread: HandlerThread? = null
    private var bgHandler: Handler? = null

    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    // ---------------------------------------------------------------- camera

    @SuppressLint("MissingPermission")
    fun startCamera() {
        if (cameraDevice != null || opening) return
        val st = renderer.surfaceTexture
        if (st == null) {
            // GL әлі дайын емес: дайын болғанда renderer өзі шақырады
            renderer.pendingStart = true
            return
        }
        opening = true

        bgThread = HandlerThread("camera").also { it.start() }
        bgHandler = Handler(bgThread!!.looper)

        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = manager.cameraIdList.firstOrNull {
            manager.getCameraCharacteristics(it)
                .get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: manager.cameraIdList.first()

        val map = manager.getCameraCharacteristics(id)
            .get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val size = chooseSize(map.getOutputSizes(SurfaceTexture::class.java))
        st.setDefaultBufferSize(size.width, size.height)
        renderer.cameraAspect = size.width.toFloat() / size.height

        manager.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(camera: CameraDevice) {
                cameraDevice = camera
                opening = false
                createSession(camera, Surface(st))
            }

            override fun onDisconnected(camera: CameraDevice) {
                camera.close(); cameraDevice = null; opening = false
            }

            override fun onError(camera: CameraDevice, error: Int) {
                camera.close(); cameraDevice = null; opening = false
            }
        }, bgHandler)
    }

    @Suppress("DEPRECATION")
    private fun createSession(camera: CameraDevice, surface: Surface) {
        camera.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                session = s
                val req = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                    addTarget(surface)
                    set(CaptureRequest.CONTROL_AF_MODE,
                        CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                }
                s.setRepeatingRequest(req.build(), null, bgHandler)
            }

            override fun onConfigureFailed(s: CameraCaptureSession) {}
        }, bgHandler)
    }

    fun stopCamera() {
        session?.close(); session = null
        cameraDevice?.close(); cameraDevice = null
        opening = false
        bgThread?.quitSafely(); bgThread = null; bgHandler = null
    }

    /** 1280x720-ке жақын өлшемді таңдау: төмен latency + жеткілікті сапа. */
    private fun chooseSize(sizes: Array<Size>): Size =
        sizes.filter { it.width * 9 == it.height * 16 }
            .minByOrNull { abs(it.width - 1280) }
            ?: sizes.minByOrNull { abs(it.width - 1280) + abs(it.height - 720) }!!

    // -------------------------------------------------------------- renderer

    private inner class StereoRenderer : Renderer, SurfaceTexture.OnFrameAvailableListener {

        var surfaceTexture: SurfaceTexture? = null
        @Volatile var pendingStart = false
        @Volatile var cameraAspect = 16f / 9f

        private var texId = 0
        private var program = 0
        private var viewW = 1
        private var viewH = 1
        private val texMatrix = FloatArray(16)

        // Линза параметрлері (Cardboard-ға ұқсас, VR Box Mini-ге қарай өзгертуге болады)
        private val k1 = 0.22f
        private val k2 = 0.24f
        // Көз арасындағы қашықтыққа сай суретті ішке/сыртқа жылжыту (-0.1..0.1)
        private val eyeShift = 0.0f

        private val quad: FloatBuffer = ByteBuffer.allocateDirect(8 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
            }

        private val vsh = """
            attribute vec2 aPos;
            varying vec2 vUv;
            void main() {
                vUv = aPos * 0.5 + 0.5;
                gl_Position = vec4(aPos, 0.0, 1.0);
            }
        """.trimIndent()

        private val fsh = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vUv;
            uniform samplerExternalOES uTex;
            uniform mat4 uTexMatrix;
            uniform vec2 uCrop;
            uniform float uK1;
            uniform float uK2;
            uniform float uShift;
            uniform float uRot180;
            void main() {
                vec2 p = vUv * 2.0 - 1.0;
                float r2 = dot(p, p);
                vec2 pd = p * (1.0 + uK1 * r2 + uK2 * r2 * r2);
                pd.x += uShift;
                if (abs(pd.x) > 1.0 || abs(pd.y) > 1.0) {
                    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
                    return;
                }
                vec2 uv = pd * 0.5 + 0.5;
                uv = 0.5 + (uv - 0.5) * uCrop;
                if (uRot180 > 0.5) uv = 1.0 - uv;
                vec2 t = (uTexMatrix * vec4(uv, 0.0, 1.0)).xy;
                gl_FragColor = texture2D(uTex, t);
            }
        """.trimIndent()

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            program = buildProgram(vsh, fsh)

            val tex = IntArray(1)
            GLES20.glGenTextures(1, tex, 0)
            texId = tex[0]
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

            surfaceTexture = SurfaceTexture(texId).also { it.setOnFrameAvailableListener(this) }
            if (pendingStart) {
                pendingStart = false
                post { startCamera() }
            }
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            viewW = width
            viewH = height
        }

        override fun onDrawFrame(gl: GL10?) {
            val st = surfaceTexture ?: return
            st.updateTexImage()
            st.getTransformMatrix(texMatrix)

            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUseProgram(program)

            // Әр көздің аспектісі: (w/2)/h; камера аспектіне қарай ортасынан қырқамыз
            val eyeAspect = (viewW / 2f) / viewH
            val cropU: Float
            val cropV: Float
            if (eyeAspect < cameraAspect) {
                cropU = eyeAspect / cameraAspect; cropV = 1f
            } else {
                cropU = 1f; cropV = cameraAspect / eyeAspect
            }

            val rotation = (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager)
                .defaultDisplay.rotation
            val rot180 = if (rotation == Surface.ROTATION_270) 1f else 0f

            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(program, "uTex"), 0)
            GLES20.glUniformMatrix4fv(
                GLES20.glGetUniformLocation(program, "uTexMatrix"), 1, false, texMatrix, 0)
            GLES20.glUniform2f(GLES20.glGetUniformLocation(program, "uCrop"), cropU, cropV)
            GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "uK1"), k1)
            GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "uK2"), k2)
            GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "uRot180"), rot180)

            val aPos = GLES20.glGetAttribLocation(program, "aPos")
            GLES20.glEnableVertexAttribArray(aPos)
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)

            val uShift = GLES20.glGetUniformLocation(program, "uShift")
            val half = viewW / 2

            // Сол көз
            GLES20.glViewport(0, 0, half, viewH)
            GLES20.glUniform1f(uShift, eyeShift)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

            // Оң көз
            GLES20.glViewport(half, 0, half, viewH)
            GLES20.glUniform1f(uShift, -eyeShift)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

            GLES20.glDisableVertexAttribArray(aPos)
        }

        override fun onFrameAvailable(st: SurfaceTexture?) {
            requestRender()
        }

        private fun buildProgram(v: String, f: String): Int {
            fun compile(type: Int, src: String): Int {
                val s = GLES20.glCreateShader(type)
                GLES20.glShaderSource(s, src)
                GLES20.glCompileShader(s)
                return s
            }
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, v))
            GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, f))
            GLES20.glLinkProgram(p)
            return p
        }
    }
}
